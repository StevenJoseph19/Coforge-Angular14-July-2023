export interface IBook {
    id: number;
    name: string;
}
